/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file complejos.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#include "../include/complejos.h"

Complejos::Complejos(double real, double imaginario) : real_(real), imaginario_(imaginario) {}

double Complejos::getReal() const {
  return real_;
};

double Complejos::getImaginario() const {
  return imaginario_;
};

Complejos Complejos::operator+(const Complejos& other) const {
  Complejos resultado(getReal() + other.getReal(), getImaginario() + other.getImaginario());
  return resultado;
};

Complejos Complejos::operator-(const Complejos& other) const {
    Complejos resultado(getReal() - other.getReal(), getImaginario() - other.getImaginario());
    return resultado;
};

Complejos Complejos::operator*(const Complejos& other) const {
    Complejos resultado((getReal() * other.getReal()) + (getImaginario() * other.getImaginario()), (getReal() * other.getImaginario()) + (getImaginario() * other.getReal()));
    return resultado;
};

Complejos Complejos::operator/(const Complejos& other) const {
    Complejos resultado((getReal() * other.getReal() + (getImaginario() * other.getImaginario()) / std::pow(other.getReal(), 2) + std::pow(other.getImaginario(), 2)),
                        ((getImaginario() * other.getReal()) - getReal() * other.getImaginario()) / (std::pow(other.getReal(), 2) + std::pow(other.getImaginario(), 2)));
    return resultado;
};

std::ostream& operator<<(std::ostream& os, const Complejos& Complejos) {
    os << Complejos.getReal() << " + " << Complejos.getImaginario() << "i";
    return os;
};