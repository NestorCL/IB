/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file complejos_main.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#include "../include/complejos.h"

int main() {
    Complejos numero1{4, 5}, numero2{7, -8};
    
    std::cout << numero1 + numero2 << std::endl;
    std::cout << numero1 - numero2 << std::endl;
    std::cout << numero1 * numero2 << std::endl;
    std::cout << numero1 / numero2 << std::endl;
    
    return 0;
}