/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file complejos.h
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#ifndef COMPLEJOS_H
#define COMPLEJOS_H

#include <iostream>
#include <cmath>

class Complejos {
    public:
        //constructores
        Complejos() {}
        Complejos(double, double);

        //getters
        double getReal() const;
        double getImaginario() const;

        //operadores sobrecargados
        Complejos operator+(const Complejos& other) const;
        Complejos operator-(const Complejos& other) const;
        Complejos operator*(const Complejos& other) const;
        Complejos operator/(const Complejos& other) const;

    private:
        //atributos
        double real_;
        double imaginario_;

};
std::ostream& operator<<(std::ostream& os, const Complejos&);

#endif //COMPLEJOS_H