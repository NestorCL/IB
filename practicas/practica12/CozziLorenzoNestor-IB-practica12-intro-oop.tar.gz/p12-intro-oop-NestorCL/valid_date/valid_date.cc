/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file valid_date.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#include "valid_date.h"

Fecha::Fecha(int day, int month, int year) : day_(day), month_(month), year_(year) {}

int Fecha::getDay() const {
    return day_;
}

int Fecha::getMonth() const {
    return month_;
}

int Fecha::getYear() const {
    return year_;
}

bool Fecha::IsBisiesto(int year) const {
    if (getYear() % 4 == 0 && getYear() % 100 != 0 || getYear() % 400 == 0) {
        return true;
    }
}

bool Fecha::ValidDate(int day, int month, int year) const {
    if (getDay() < 1 || getDay() > 31 || getMonth() < 1 || getMonth() > 31 || getYear() < 1) {
        return false;
    } 
}