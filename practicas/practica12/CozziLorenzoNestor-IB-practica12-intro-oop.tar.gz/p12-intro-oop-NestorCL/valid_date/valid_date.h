/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file valid_date.h
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#ifndef VALID_DATE_H
#define VALID_DATE_H

#include <iostream>

class Fecha {
    public:
        Fecha() {}
        Fecha(int, int, int);

        int getDay() const;
        int getMonth() const;
        int getYear() const;

        bool IsBisiesto(int año) const;
        bool ValidDate(int day, int month, int year) const;

    
    private:
        int day_;
        int month_;
        int year_;

};

#endif //VALID_DATE_H