/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file point2D.h
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#ifndef POINT2D_H
#define POINT2D_H

#include <iostream>
#include <cmath>

class Point2D {
    public:
        Point2D() {}
        Point2D(double, double);
        
        double getX() const;
        double getY() const;

        void Show() const;
        void Move(double nexX, double newY);
        double Distance(const Point2D& other) const;
        Point2D Middle(const Point2D& other) const;

    private:
        double x_;
        double y_;

};
std::ostream& operator<<(std::ostream& os, const Point2D&);

#endif //POINT2D_H