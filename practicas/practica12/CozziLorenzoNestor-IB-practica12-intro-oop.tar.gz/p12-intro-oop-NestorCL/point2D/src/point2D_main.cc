/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file point2D_main.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#include "../include/point2D.h"

int main() {
    Point2D punto1(2, 4), punto2(3, 7);

    std::cout << "Los puntos con los que vamos a trabajar son: " << std::endl;
    std::cout << punto1 << " y " << punto2 << std::endl;
    std::cout << std::endl;

    double newx, newy;
    std::cout << "Introduce las coordenas (x, y) en las que quiera que se mueva el punto: " << std::endl;
    std::cin >> newx >> newy;
    std::cout << "El punto ha sido movido a la posición: ";
    punto1.Move(newx, newy);
    std::cout << std::endl;
    
    std::cout << "La distancia entre los puntos es: " << punto1.Distance(punto2) << std::endl;
    std::cout << std::endl;

    std::cout << "El punto medio entre ambos puntos es: " << punto1.Middle(punto2) << std::endl;

    return 0;
}