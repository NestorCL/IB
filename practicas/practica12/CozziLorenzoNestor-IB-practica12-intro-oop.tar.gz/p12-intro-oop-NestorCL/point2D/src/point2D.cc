/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file point2D.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#include "../include/point2D.h"

Point2D::Point2D(double x, double y) : x_(x), y_(y) {}

double Point2D::getX() const {
    return x_;
};

double Point2D::getY() const {
    return y_;
};

void Point2D::Show() const {
    std::cout << "(" << getX() << ", " << getY() << ")" << std::endl;
};

void Point2D::Move(double newX, double newY) {
    std::cout << "(" << getX() + newX << ", " << getY() + newY << ")" << std::endl;
};

double Point2D::Distance(const Point2D& other) const {
    double resultado(sqrt(std::pow(getX() - other.getX(), 2) + std::pow(getY() - other.getY(), 2)));
    return resultado;
};

Point2D Point2D::Middle(const Point2D& other) const {
    Point2D resultado((getX() + other.getX()) / 2, (getY() + other.getY()) / 2);
    return resultado;
};

std::ostream& operator<<(std::ostream& os, const Point2D& point2D) {
    os << "(" << point2D.getX() << " ," << point2D.getY() << ")";
    return os;
};