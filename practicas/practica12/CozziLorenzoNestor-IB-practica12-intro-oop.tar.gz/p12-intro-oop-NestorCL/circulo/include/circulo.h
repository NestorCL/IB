/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file circulo_main.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#ifndef CIRCULO_H
#define CIRCULO_H

#include <iostream>
#include <cmath>
#include <string>

class Circulo {
    public:
        Circulo() {}
        Circulo(double, double, double);

        double getX() const;
        double getY() const;
        double getRadio() const;

        double Area() const;
        double Perimetro() const;
        void Print () const;
        bool EsInterior(double otherX, double otherY) const;

    private:
        double x_;
        double y_;
        double radio_;
};

#endif //CIRCULO_H