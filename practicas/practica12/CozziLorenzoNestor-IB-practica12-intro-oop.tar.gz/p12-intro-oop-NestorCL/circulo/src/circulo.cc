/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file circulo_main.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#include "../include/circulo.h"

Circulo::Circulo(double x, double y, double radio) : x_(x), y_(y), radio_(radio) {}

double Circulo::getX() const {
    return x_;
};

double Circulo::getY() const {
    return y_;
};

double Circulo::getRadio() const {
    return radio_;
};

double Circulo::Area() const {
    double area(3.14 * std::pow(getRadio(), 2));
    return area;
};

double Circulo::Perimetro() const {
    double perimetro(2 * 3.14 * getRadio());
    return perimetro;
};

void Circulo::Print() const {
    std::cout << "El punto medio del círculo es (" << getX() << ", " << getY() << ") con un radio de " << getRadio() << std::endl;
    std::cout << "Su área es: " << Area() << std::endl;
    std::cout << "Su perímetro es: " << Perimetro() << std::endl;
};

bool Circulo::EsInterior(double otherX, double otherY) const {
    double distancia = sqrt(std::pow(otherX - getX(), 2) + std::pow(otherY - getY(), 2));
    if (distancia <= getRadio()) {
        std::cout << "El punto está dentro del círculo" << std::endl;
        return true;
    }
    std::cout << "EL punto no está dentro del círculo" << std::endl;
    return false;
};
