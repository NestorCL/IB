/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file circulo_main.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 2-12-2025
  * @brief
  */

#include "../include/circulo.h"

  int main() {
    Circulo circulo1(0, 0, 5);

    circulo1.Print();

    double otherX(2), otherY(3);
    circulo1.EsInterior(otherX, otherY);

    return 0;
}