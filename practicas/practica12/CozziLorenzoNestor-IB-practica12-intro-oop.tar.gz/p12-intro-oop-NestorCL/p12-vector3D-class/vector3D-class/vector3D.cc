/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F de Sande
 * @date Dec 16 2022
 * @brief Vector3D class Implementation
 */

#include <iostream>
#include <cmath>

#include "vector3D.h"

/**
 * @brief Inserts the vector in the output stream
 *        Overloading the insertion (<<) operator
 * @param[in] output: The output stream where text is inserted
 * @param[in] vector: the vector to print
 * @return an ostream reference (the operator can be chained)
 */
std::ostream& operator<<(std::ostream& output, const Vector3D& vector) {
  output << '(' << vector.X_position() << ", " << vector.Y_position() << ", " << vector.Z_position() << ")\n";
  return output;
};

Vector3D vector_module(double num) const {
  return Vector3D(X_position() * num, Y_position() * num, Z_position() * num);
};


Vector3D Vector3D::operator+(const Vector3D& other) const {
  Vector3D sum_vector(X_position() + other.X_position(), Y_position() + other.Y_position(), Z_position() + other.Z_position()); 
  return sum_vector;
};

