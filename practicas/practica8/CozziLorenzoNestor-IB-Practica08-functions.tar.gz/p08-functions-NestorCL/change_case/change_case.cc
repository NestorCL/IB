/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file change_case.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 31-10-2025
  * @brief El programa cambia de mayúsculas a minusculas y viceversa las letras de una palabra
						sin cambiar aquello que no sean letras
  */

#include<iostream>
#include<string>

char MinToMay(int letra) {
	return char(letra - 32);
}
	
char MayToMin(int letra) {
	return char(letra + 32);
}

int main() {
	std::string palabra;
	std::string nueva;
	std::cout << "Introduce la palabra a cambiar: ";
	std::cin >> palabra;

	for (int i = 0; i < palabra.size(); i++) {
		int letra = int(palabra[i]);

		if (letra >= 97 && letra <= 122) {
		nueva.push_back(MinToMay(letra));
		
		} else if (letra >= 65 && letra <= 90) {
			nueva.push_back(MayToMin(letra));

		} else {
			nueva.push_back(char(letra));
		}
	}
	std::cout << nueva << std::endl;
	return 0;
}
