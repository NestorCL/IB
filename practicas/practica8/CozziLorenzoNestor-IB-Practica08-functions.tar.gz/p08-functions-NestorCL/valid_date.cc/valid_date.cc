/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file valid_date.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 6-11-2025
  * @brief El programa respalda si una fecha introducida es verdadera o falsa
  */

#include <iostream>

bool IsValid (int d,int m, int y) {	
	if (d < 32 && d > 0 && m < 13 && m > 0 && y < 2026 && y >= 1800) {
		std::cout << "true" << std::endl;
		return true;
	} else {
		std::cout << "false" << std::endl;
		return false;
	}
	
	if (y % 4 == 0) {
		if (y % 100 != 0 && y % 400 == 0) {
			std::cout << "Además es bisiesto" << std::endl;
		}
	}
}

int main(int argc, char* argv[]) {
	int d = std::stoi(argv[1]);
	int m = std::stoi(argv[2]);
	int y = std::stoi(argv[3]);

	std::cout << IsValid(d, m, y) << std::endl;
	return 0;
}
