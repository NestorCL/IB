/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file function_example.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 31-10-2025
  * @brief El programa calcula el valor de una función dependiendo de unso valores
  */

#include <iostream>
#include <cmath>

double Numerador(double t) {
	double numerador = std::sqrt((2 * t) - 4);
	return numerador;
}

double Denominador(double x, double y) {
	double denominador = pow(x, 2) - pow(y, 2);
	return denominador;
}

int main() {
	double x, y, t, resultado;
	std::cout << "Define los valores para g(x,y,t): ";
	std::cin >> x >> y >> t;
	
	if(t < 2) {
		std::cerr << "Este valor para z no es válido" << std::endl;
		return 1;
	} else {
		resultado = Numerador(t) / Denominador(x, y);
		std::cout << "g(" << x << "," << y << "," << t << ") = " << resultado << std::endl;
	}
	return 0;
}
