/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file random_numbers.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 31-10-2025
  * @brief El programa devuelve un número de un intervalo de dos números que se le da al programa
  */

/*
	#include<cstdlib>
	
	int main() {
		srand(time(0));
		for(int i = 0; i <= 5; i++) {
			std::cout << rand() << std::endl;
		}
		return 0;
	}
*/

#include<iostream>
#include<random>

void Check (int min, int max) {
	if (max < min || min < 0) {
		std::cerr << "Estos valores no son válidos, recuerda que deben ser positvos y el 1º < 2º" << std::endl;
	}
}

int Generador (int min, int max) {
	std::random_device rd;
	std::mt19937 gen(rd());
	std::uniform_int_distribution<> distrib(min, max);
	return distrib(gen);
}

int main() {
	int min, max;
	std::cout << "Introduce 2 números: ";
	std::cin >> min >> max;
	
	Check(min, max);

	std::cout << "Un número aleatorio entre " << min << " y " << max << " es: " << Generador(min, max) << std::endl;
	return 0;	
}
