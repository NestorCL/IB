/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file are_equal.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 4-11-2025
  * @brief El programa compara 2 números de 2 maneras distintas, 
  */

#include <iostream>
#include <cmath>

bool AreEqual(double num1, double num2, const double epsilon = 1e-7) {
	if (fabs(num1 - num2) > epsilon) {
		std::cout << "Realmente no son iguales" << std::endl;
		return false;
	} else {
		std::cout << "Si son iguales" << std::endl;
		return true;
	}
}

int main() {
	double num1, num2;
	std::cout << "Introduce el mismo número 2 veces: ";
	std::cin >> num1 >> num2;

	if (num1 == num2) {
		std::cout << "Si son igules" << std::endl;
	} else {
		std::cout << "No son iguales" << std::endl;
	}

	AreEqual(num1, num2);

	return 0;
}
