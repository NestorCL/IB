/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file triangle_area.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 5-11-2025
  * @brief El programa cálcula el área de un triangulo con la fórmula de herón
  */

#include <iostream>
#include <cmath>
#include <iomanip>

double DesigualdadTriangular(double a, double b, double c) {
	if (a > b + c || b > a + c || c > a + b) {
		std::cout << "El triangulo no es válido" << std::endl;
		return 1;
	}
	return 0;
}

double Area(double a, double b, double c) {
	double s = (a + b + c) / 2;
	double resultado = std::sqrt(s * (s - a) * (s - b) * (s - c));
	return resultado;
}

int main(int argc, char* argv[]) {
	
	if (argc > 4) {
		std::cerr << "Debe introducir 3 valores numéricos" << std::endl;
		return 1;	
	}
	
	double a = std::stod(argv[1]);
	double b = std::stod(argv[2]);
	double c = std::stod(argv[3]);
	
DesigualdadTriangular(a, b, c);

	std::cout << std::fixed << std::setprecision(2) << Area(a, b, c) << std::endl;
	return 0;
}
