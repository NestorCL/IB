/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file factorial.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 6-11-2025
  * @brief El programa calcula el factorial del número dado
  */

#include <iostream>
#include <string>

int Factorial(int n) {
	int resultado(1);
	for (int i = n; i > 0; i--) {
		resultado *= i;
	}
	return resultado;
}

int main(int argc, char* argv[]) {
	int n = std::stoi(argv[1]);
	
	std::cout << Factorial(n) << std::endl;
	return 0;
}
