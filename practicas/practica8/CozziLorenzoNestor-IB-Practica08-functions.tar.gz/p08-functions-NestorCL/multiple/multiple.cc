/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file multiple.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 6-11-2025
  * @brief El programa calcula se el número dado es múltiplo de 3
  */

#include <iostream>

bool IsMultiple(int n) {
	int sum(0);
	for (int i = n; i > 0; i++) {
		sum += n % 10;
		n /= 10;
	}

	if (sum % 3 == 0) {
		std::cout << "true" << std::endl;
		return true;
	} else {
		std::cout << "false" <<std::endl;
		return false;
	}
}

int main(int argc, char* argv[]) {
	int n = std::stoi(argv[1]);

	std::cout << IsMultiple(n) << std::endl;
	return 0;
}
