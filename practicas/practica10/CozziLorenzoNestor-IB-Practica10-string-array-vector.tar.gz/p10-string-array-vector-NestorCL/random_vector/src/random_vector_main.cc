/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file random_vector.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

  #include "../include/random_vector.h"

  int main(int argc, char* argv[]) {
    int size = std::stoi(argv[1]);
    double lower = std::stod(argv[2]);
    double upper = std::stod(argv[3]);

    if (argc > 4) {
      std::cerr << "Ha de introducir 3 valores: Tamaño, mínimo y máximo" << std::endl;
      return 1;
    }

    std::vector<double> random_vector(GenerateVector(size, lower, upper));

    for (const auto& value : random_vector) {
      std::cout << value << std::endl;
    }
  }