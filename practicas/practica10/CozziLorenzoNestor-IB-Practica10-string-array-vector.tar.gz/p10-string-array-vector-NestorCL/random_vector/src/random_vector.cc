/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file random_vector.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include "../include/random_vector.h"

std::vector<double> GenerateVector(int size, double lower, double upper) {
  std::mt19937 rng(std::chrono::steady_clock::now().time_since_epoch().count());
  std::uniform_real_distribution<double> dist(lower, upper);

  std::vector<double> vector;
  vector.reserve(size);

  for (int i = 0; i < size; i++) {
    vector.push_back(dist(rng));
  }
  return vector;
}