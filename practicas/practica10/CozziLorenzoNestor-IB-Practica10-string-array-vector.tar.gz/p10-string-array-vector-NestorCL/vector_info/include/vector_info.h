/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file vector_info.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include <iostream>
#include <string>
#include <vector>

void CalcularEstadisticas(const std::vector<double>& vector, double& maximo, double& minimo, double& promedio);

std::vector<double> GenerateVector(int argc, char* argv[]);