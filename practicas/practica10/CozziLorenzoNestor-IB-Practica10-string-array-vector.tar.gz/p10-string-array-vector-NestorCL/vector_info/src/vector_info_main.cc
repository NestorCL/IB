/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file vector_info.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include "../include/vector_info.h"

int main(int argc, char* argv[]) {
    std::vector<double> vector = GenerateVector(argc, argv);

    double maximo, minimo, promedio;
    CalcularEstadisticas(vector, maximo, minimo, promedio);
    
    std::cout << "Máximo: " << maximo << std::endl;
    std::cout << "Mínimo: " << minimo << std::endl;
    std::cout << "Promedio: " << promedio << std::endl;

    return 0;
}