/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file vector_info.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include "../include/vector_info.h"

void CalcularEstadisticas(const std::vector<double>& vector, double& maximo, double& minimo, double& promedio) {
  if (vector.empty()) {
    maximo = minimo = promedio = 0.0;
    return;
  }

  maximo = vector[0];
  minimo = vector[0];
  double suma = 0.0;

  for (double num : vector) {
    if (num > maximo) maximo = num;
    if (num < minimo) minimo = num;
    suma += num;
  }

  promedio = suma / vector.size();
}

std::vector<double> GenerateVector(int argc, char* argv[]) {
  std::vector<double> vector;
  for (int i = 1; i < argc; i++) {
    vector.push_back(std::stod(argv[i]));
  }
  return vector;
}
