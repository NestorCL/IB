/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file reduce_sum.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

std::vector<double> GenerateVector(int argc, char* argv[]);

float ReduceSum(const std::vector<double>& vector);