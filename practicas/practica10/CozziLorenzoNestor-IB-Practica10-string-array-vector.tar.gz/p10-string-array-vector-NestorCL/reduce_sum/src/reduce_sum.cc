/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file reduce_sum.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include "../include/reduce_sum.h"

std::vector<double> GenerateVector(int argc, char* argv[]) {
  std::vector<double> vector {};
  for (int i = 1; i < argc; i++) {
    vector.push_back(std::stod(argv[i]));
  }
  return vector;
}

float ReduceSum(const std::vector<double>& vector) {
  float suma = 0.0;
  for (int i = 0; i < vector.size(); i++) {
    suma += vector[i];
  }
  return suma;
}