/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file reduce_sum.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include "../include/reduce_sum.h"

int main(int argc, char* argv[])  {
  std::vector<double> vector = GenerateVector(argc, argv);
  
  std::cout << ReduceSum(vector) << std::endl;
  return 0;
}