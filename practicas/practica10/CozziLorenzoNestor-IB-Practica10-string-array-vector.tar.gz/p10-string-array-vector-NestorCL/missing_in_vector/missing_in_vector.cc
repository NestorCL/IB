/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date
  * @brief
  */

#include <iostream>
#include <vector>

int MissingVector(std::vector<int> vector) { 
		for (int = 0; i < vector.size(); i++) {
		int suma_vector = vector[i] * (vector[i] + 1) / 2;
		int	aux = 0;
			aux += vector[i];
		return suma_vector - numero;
	}
}


int main() {
	std::vector<int> vector;	
	while (std::cin >> numero) {
		vector.push_back(numero);
	}
		MissingVector(numero);

	
	return 0;
}
