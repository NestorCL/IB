/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file shuffle_vector.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include "../include/shuffle_vector.h"

void ShuffleVector(std::vector<int>& vector) {
  int n = vector.size();
  for (int i = 0; i < n; ++i) {
    int j = std::rand() % n;
    std::swap(vector[i], vector[j]);
  }
}