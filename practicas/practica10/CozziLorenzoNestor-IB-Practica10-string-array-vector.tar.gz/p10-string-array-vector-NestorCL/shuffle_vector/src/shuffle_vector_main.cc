/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file shuffle_vector.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 19-11-2025
  * @brief
  */

#include "../include/shuffle_vector.h"

int main() {
    std::srand(std::time(nullptr));

    std::vector<int> vector{1, 2, 3, 4, 5, 6, 7, 8, 9};

    std::cout << "Vector original: ";
    for (int v : vector) std::cout << v << " ";
    std::cout << "\n";

    ShuffleVector(vector);

    std::cout << "Vector desordenado: ";
    for (int v : vector) std::cout << v << " ";
    std::cout << "\n";

    return 0;
}