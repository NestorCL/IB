#include <iostream>
int main() {
	int radio, altura;
	double pi{3.14}, volumen;
	std::cout << "Introduce el radio y la altura del cono a calcular: " ;
	std::cin >> radio >> altura;
	volumen = pi * radio * radio * altura;
	std::cout << "Un cono de radio " << radio << " y altura " << altura << " tiene un volumen de " << volumen / 3 << std::endl;
	return 0;
}
