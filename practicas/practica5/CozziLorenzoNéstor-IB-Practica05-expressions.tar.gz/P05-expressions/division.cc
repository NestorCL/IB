#include <iostream>
int main() {
	int dividendo, divisor, cociente, resto;
	double real;
	std::cout << "Introduzca un valor: " ;
	std::cin >> dividendo;
	std::cout << "Introduzca otro valor: " ;
	std::cin >> divisor;
	cociente = dividendo / divisor;
	std::cout << "Div. entera: " << cociente << std::endl;
	resto = dividendo % divisor;
	std::cout << "Resto: " << resto << std::endl;
	real = double(dividendo) / double(divisor);
	std::cout << "Div.real: " << real << std::endl;
	return 0;
}
