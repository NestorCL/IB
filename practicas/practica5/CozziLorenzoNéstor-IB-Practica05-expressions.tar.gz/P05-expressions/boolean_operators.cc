#include <iostream>
int main() {
	bool a{0}, b{0};
	// a = true
	// b = 1;
	
	std::cout << /* std::boolalpha << */ "A | B | A and B | A or B | not A" << std::endl;
	for (int i = 0; i <= 1; ++i) {
		for (int j = 0; j <= 1; ++j) {
			std::cout << a << " | " << b << " |    " << (a && b) << "    |    " << (a || b) << "   |  " << !a << std::endl;
			b = 1; 
		}
		a = 1;
		b = 0;
	}
	return 0;
	}
