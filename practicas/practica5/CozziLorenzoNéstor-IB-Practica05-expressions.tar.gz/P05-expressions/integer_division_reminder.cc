/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date
  * @brief
  */

#include <iostream>
int main () {
	int dividendo, divisor, cociente, resto;
	std::cout << "Introduzca dos números q serán divididos: " ;
	std::cin >> dividendo >> divisor;
	if (dividendo <= 0 | divisor <= 0) {
		std::cout << "Los valores han de ser positivos" << std::endl;
		return 1;
	}
	cociente = dividendo / divisor;
	resto = dividendo % divisor;
	std::cout << cociente << " " << resto << std::endl;
	return 0;
}
