#include <iostream>
int main() {
	double a, b;
	int c, d;
	std::cout << "Introduce 2 valores: " ;
	std::cin >> a >> b;
	c = a;
	d = b;
	std::cout << a << " + " << b << " = " << a + b << std::endl;
	std::cout << a << " - " << b << " = " << a - b << std::endl;
	std::cout << a << " * " << b << " = " << a * b << std::endl;
	std::cout << a << " / " << b << " = " << a / b << std::endl;
	std::cout << a << " % " << b << " = " << c % d << std::endl;
	return 0;
	}
