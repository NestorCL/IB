#include <iostream>
int main() {
	char may;
	int min;
	std::cout << "Introduce una letra mayúscula: " ;
	std::cin >> may;
	if (int(may) <= 64 || int(may) >= 91) {
		std::cout << "Esto no es una letra mayúscula" << std::endl;
		return 1;
	}
	min = int(may) + 32;
	std::cout << char(min) << std::endl;
	return 0;
}
