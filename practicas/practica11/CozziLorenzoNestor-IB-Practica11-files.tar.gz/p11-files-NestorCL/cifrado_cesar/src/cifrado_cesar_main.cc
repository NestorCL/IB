/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file cifrado_cesar.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 21-11-2025
  * @brief El programa aplica el cifrado césar a un texto dado
  */

#include "../include/cifrado_cesar.h"

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Asegurese de tener un archivo de entrada y otro de salida" << std::endl;
        return 1;
    }
    
    std::string original = argv[1];
    std::string cifrado = argv[2];
    
    std::ifstream ifs(original);
    ifs.is_open();
    if (!ifs.is_open()) {
        return 1;
    }
    std::string palabras;
    getline(ifs, palabras);

    int clave;
    std::cout << "Introduce un número para encriptar el mensaje: " << std::endl;
    std::cin >> clave;

    std::ofstream ofs(cifrado);
    ofs.is_open();
    if (!ofs.is_open()) {
        return 1;
    }

    ofs << Encriptar(palabras, clave);

    ifs.close();
    ofs.close();
    return 0;
}