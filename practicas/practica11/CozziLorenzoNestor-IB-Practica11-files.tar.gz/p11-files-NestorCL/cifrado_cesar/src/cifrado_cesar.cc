/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file cifrado_cesar.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 21-11-2025
  * @brief El programa aplica el cifrado césar a un texto dado
  */

#include "../include/cifrado_cesar.h"

std::string Encriptar(std::string palabras, int clave) {
    std::string mensaje;
    for (int i = 0; i < palabras.size(); i++) {
        mensaje.push_back(palabras[i] + clave);
    }
    return mensaje;
}