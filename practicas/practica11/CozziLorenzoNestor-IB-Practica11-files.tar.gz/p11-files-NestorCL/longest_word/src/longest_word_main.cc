/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file longest_word_main.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 21-11-2025
  * @brief El programa muestra la palabra con mayor número de vocales y consonantes
  */

#include "../include/longest_word.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Asegurese de tener un fichero con el texto a analizar" << std::endl;
        return 1;
    }

    std::string texto = argv[1];

    std::ifstream ifs(texto);
    ifs.is_open();
    if (!ifs.is_open()) {
        return 1;
    }
    std::string linea;
    getline(ifs, linea);

    std::vector<std::string> lyrics;
    std::string palabra;
    std::istringstream iss(linea);
    while (iss >> palabra) {
        lyrics.push_back(palabra);
    }

    std::cout << "La palabra más larga es: " << LongestWord(lyrics) << std::endl;
    VocalesConsonantes(lyrics);

    ifs.close();
    return 0;
}