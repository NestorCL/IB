/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file longest_word.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 21-11-2025
  * @brief El programa muestra la palabra con mayor número de vocales y consonantes
  */

#include "../include/longest_word.h"

std::string LongestWord(std::vector<std::string> lyrics) {
    int longmax = 0;
    std::string longest;
    for (int i = 0; i < lyrics.size(); i++) {
        if (lyrics[i].size() > longmax) {
            longmax = lyrics[i].size();
            longest = lyrics[i];
        }
    }
    return longest;
}

void VocalesConsonantes(std::vector<std::string> lyrics) {
    int vocales(0), consonantes(0), maxvocales(0), maxconsonantes(0);
    std::string maxV, maxC;
    for (std::string palabra : lyrics) {
        for (char letra : palabra) {
             if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u' ||
                 letra == 'A' || letra == 'E' || letra == 'I' || letra == 'O' || letra == 'U') {
                    vocales += 1;
                } else {
                    consonantes += 1;
                }
            }

        if (maxvocales < vocales) {
            maxvocales = vocales;
            maxV = palabra;
        }
        
        if (maxconsonantes < consonantes) {
            maxconsonantes = consonantes;
            maxC = palabra;
        }
        vocales = 0;
        consonantes = 0;
        }
    std::cout << "La palabra con el mayor número de vocales es: " << maxV << std::endl;
    std::cout << "La palabra con el mayor número de consonantes es: " << maxC << std::endl;
}