/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file longest_word.h
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 21-11-2025
  * @brief El programa muestra la palabra con mayor número de vocales y consonantes
  */

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>

std::string LongestWord(std::vector<std::string> lyrics);

void VocalesConsonantes(std::vector<std::string> lyrics);