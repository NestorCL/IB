/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date
  * @brief
  i*/

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

/*
	La función cambia la letra por la siguiente en el abecedario
*/

void CambioLetra(std::string linea) {
	for(char letra : linea) {
		if (letra > 64 && letra < 90) {
			letra += 1;
		}
		else if (letra > 97 && letra < 121) {
			letra += 1;
		}
		else if (letra == 'z') {
			letra = char(97);
		}
		else if (letra == 'Z') {
			letra = char(65);
		}
	std::cout << letra;
	}
}

int main(int argc, char* argv[]) {
	if (argc != 2) {
	std::cerr << "Ha de introducir solo 2 ficheros" << std::endl;
	return 1;
	}

	std::string texto = argv[1];
	std::ifstream ifs(texto);
	ifs.is_open();
	if (!ifs.is_open()) {
		return 1;
	}

	std::string linea;
	while(getline(ifs, linea)) {
		CambioLetra(linea);
	}
	std::cout << std::endl;

	ifs.close();
	return 0;
}


