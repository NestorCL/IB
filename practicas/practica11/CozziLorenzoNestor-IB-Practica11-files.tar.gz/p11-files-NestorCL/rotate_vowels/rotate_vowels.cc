#include <string>
#include <fstream>
#include <sstream>

void RotateVowels(std::string& palabra) {
    for (int i = 0; i < palabra.size(); i++) {
        switch (palabra[i]) {
            case 'a':
                palabra[i] = 'e';
                break;           
            case 'e':
                palabra[i] = 'i';
                break;
            case 'i':
                palabra[i] = 'o';
                break;
            case 'o':
                palabra[i] = 'u';
                break;
            case 'u':
                palabra[i] = 'a';
                break;
        }
    }

    // for (int i = 0; i < palabra.size(); i++) {
    //     if (palabra[i] == 'a') {
    //         palabra[i] = 'e';
    //     } else if (palabra[i] == 'e') {
    //         palabra[i] = 'i';
    //     } else if (palabra[i] == 'i') {
    //         palabra[i] = 'o';
    //     } else if (palabra[i] == 'o') {
    //         palabra[i] = 'u';
    //     } else if (palabra[i] == 'u') {
    //         palabra[i] = 'a';
    //     }
    // }
}


int main(int argc, char* argv[]) {
    std::string normal = argv[1];
    std::string rotado = argv[2];

    std::ifstream ifs(normal);
    ifs.is_open();
    std::string linea;
    getline(ifs, linea);

    std::string palabra;
    std::istringstream iss(linea);
    
    std::ofstream ofs(rotado);
    ofs.is_open();

    while (iss >> palabra) {
        RotateVowels(palabra);
        ofs << palabra << " ";
    }
    
    ifs.close();
    ofs.close();
    return 0;
}