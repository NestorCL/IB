/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file leap_year.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 28-10-2025
  * @brief El programa te dice si el año introducido es bisiesto o no
  */

#include <iostream>
int main() {
	int año;
	std::cout << "Introduce un año: ";
	std::cin >> año;
	
	if (año % 400 == 0 || año % 4 == 0 && año % 10 != 0) {
		std::cout << "YES" << std::endl;
	} else {
		std::cout << "NO" << std::endl;
	}
	return 0;
}
