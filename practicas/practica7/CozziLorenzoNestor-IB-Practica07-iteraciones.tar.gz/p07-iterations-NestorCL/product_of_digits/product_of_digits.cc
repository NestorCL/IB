/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date
  * @brief
  */

#include<iostream>

int Producto(int num) {
	int aux{1};
	for (int i = 0; i < num; i++) {
		aux *= num % 10;
		num /= 10;
	}
	std::cout << "The product of the digits of " << num << " is " << aux << std::endl;
	return aux;
}

int main() {
	int num;

	while (std::cin >> num) {
		while (num >= 10) {
			num = Producto(num);
			std::cout << num << std::endl;
		}
		std::cout << "-----------" << std::endl;
	}
	return 0;
}
