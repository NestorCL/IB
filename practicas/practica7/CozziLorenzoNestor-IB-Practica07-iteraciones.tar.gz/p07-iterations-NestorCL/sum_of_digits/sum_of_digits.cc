/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file sum_of_digits.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 24-10-2025
  * @brief El programa hace la suma de los digitos del número que le damos
  */

#include <iostream>
#include <string>
/*
	int main() {
		std::string numero, aux{0};
		int suma{0};
		
		std::cout << "Introduce un número: ";
		std::cin >> numero;
	
		for (int i = 0; i <= numero.size(); i++) {
			suma += numero[i];
			std::cout << suma << std::endl;
		}
		std::cout << suma << std::endl;
		return 0;
	}
*/

int main() {
	int num, sum;
	std::cout << "Introduce un número: ";
	std::cin >> num;
	
	while(num > 0) {
		sum += num % 10;
		num /= 10;	
	}
	std::cout << sum << std::endl;
	return 0;
}

