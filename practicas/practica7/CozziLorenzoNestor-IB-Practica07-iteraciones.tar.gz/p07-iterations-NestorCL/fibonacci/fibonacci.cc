/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file fibonacci.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 24-10-2025
  * @brief El programa imprime el número de la secuencia de fibonacci 
	*	dependiendo de un número de entrada que son las iteraciones
  */

#include <iostream>
int main() {
	int n, bef{0}, act{1}, next;
	std::cout << "Introduce el término de la serie de fibonacci: ";
	std::cin >> n;

	for(int i = 1; i <= n; i++) {
		std::cout << bef << " ";
		next = bef + act;
		bef = act;
		act = next;
	}
	std::cout << std::endl;
	return 0;
}
