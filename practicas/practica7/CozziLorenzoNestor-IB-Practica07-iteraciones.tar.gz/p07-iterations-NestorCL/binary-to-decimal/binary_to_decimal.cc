/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file binary_to_decimal.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 28-10-2025
  * @brief Convierte los número binarios a decimales
  */

#include <iostream>
#include <cmath>

int main() {
	int binario{0}, decimal{0}, aux{0}, expo{1};
	std::cout << "Introduce un número en binario: ";
	std::cin >> binario;

	while (binario > 0) {
		aux = binario % 10;
		if (aux != 0 || aux != 1) {
			std::cout << "Eso no es un número binario" << std::endl;
			return 1;
		} else {
			decimal += aux * expo;
			expo *= 2;
			binario /= 10;
   }
	}
	std::cout << "El número decimal es " << decimal << std::endl;
	return 0;
}
