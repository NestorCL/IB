/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file polynomial_evaluation.cc P96767
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 30-10-2025
  * @brief 
  */

#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

int main() {
	double x, result;
	std::cin >> x;

  std::vector<double> poli;
  double num;
  while (std::cin >> num) {
    poli.push_back(num);
    std::cout << "YES" << std::endl; 
  }
  
  for (int i = 0; i < poli.size(); i++) {
    result += poli[i] * std::pow(x, i);
    std::cout << result << std::endl;
  }
	
  std::cout << std::fixed << std::setprecision(4) << result << std::endl;
	return 0;
}