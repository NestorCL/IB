/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file scalar_product
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 6-11-2025
  * @brief El programa calcula el producto escalar entre 2 vectores
  */

#include <iostream>
#include <string>
#include <vector>

int SameLenght(std::string vector1, std::string vector2);

int ScalarProduct(std::string vector1, std::string vector2);