/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file scalar_product
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 6-11-2025
  * @brief El programa calcula el producto escalar entre 2 vectores
  */

#include "scalar_product.h"

int SameLenght(std::string vector1, std::string vector2) {
	if (vector1.size() != vector2.size()) {
		std::cerr << "Los vectores han de tener el mismo número de términos" << std::endl;
		return 1;
	}
	return 0;
}

int ScalarProduct(std::string vector1, std::string vector2) {
	int producto(0);
	for (int i = 0; i < vector1.size(); i++) {
		producto += std::stoi(std::string(1, vector1[i])) * std::stoi(std::string(1, vector2[i]));
	}
	return producto;
}