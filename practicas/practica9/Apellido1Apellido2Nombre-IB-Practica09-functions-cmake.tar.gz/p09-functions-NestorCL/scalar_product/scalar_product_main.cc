/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file scalar_product
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 6-11-2025
  * @brief El programa calcula el producto escalar entre 2 vectores
  */

#include "scalar_product.h"

int main(int argc, char* argv[]) {
	std::string vector1(argv[1]);
	std::string vector2(argv[2]);

	if (argc > 3) {
		std::cerr << "Así debe introducir los vectores: (a1,a2,a3) (b1,b2,b3)" << std::endl;
		return 1; 
	}

	SameLenght(vector1, vector2);

	std::cout << ScalarProduct(vector1, vector2) << std::endl;
	return 0;
}
