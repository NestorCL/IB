/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file aproximate_root.h
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date	8-11-2025
  * @brief El programa calcula la raiz cuadrada de un número y comprueba que este dentro de un error epsilon
  */

  #include "aproximate_root.h"

  int main(int argc, char* argv[]) {
    double num = std::stod(argv[1]);

    if (argc > 2) {
        std::cerr << "Introduzca solo un número" << std::endl;
        return 1; 
    }

    if (num < 0) {
        std::cerr << "El número ha de ser positivo" << std::endl;
        return 1;
    }

    std::cout << "La raiz cuadrada de " << num << " es " << RaizCuadrada(num) << std::endl;
    return 0;
  }