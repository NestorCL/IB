/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file subfactorial.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 14-11-2025
  * @brief
  */

#include <iostream>
#include <cmath>

unsigned long long Factorial(int n) {
    unsigned long long resultado = 1;
    for (int i = 2; i <= n; i++) {
        resultado *= i;
    }
    return resultado;
}

int Signo(int i) {
    return (i % 2 == 0) ? 1 : -1;
}

unsigned long long Subfactorial(int n) {
    unsigned long long factN = Factorial(n);
    unsigned long long resultado = 0;

    for (int i = 0; i <= n; i++) {
        resultado += Signo(i) * (factN / Factorial(i));
    }
    return resultado;
}

int main() {
    int n;
    std::cout << "Ingrese un valor entero positivo n: ";
    std::cin >> n;

    if (n < 0) {
        std::cout << "El valor debe ser positivo." << std::endl;
        return 1;
    }

    unsigned long long resultado = Subfactorial(n);
    unsigned long long aproximacion = std::round(Factorial(n) / M_E);

    std::cout << "!n (subfactorial exacto) = " << resultado << std::endl;
    std::cout << "!n (aproximacion n!/e redondeado) = " << aproximacion << std::endl;

    if (resultado == aproximacion) {
        std::cout << "Coinciden ambos resultados." << std::endl;
    } else {
        std::cout << "No coinciden." << std::endl;
    }

    return 0;
}
