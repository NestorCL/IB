/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file hypotenuse.h
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date	8-11-2025
  * @brief El programa calcula la hipotenusa de dos números dados
  */

#include "hypotenuse.h"

int main(int argc, char* argv[]) {
    double num1 = stod(argv[1]);
    num1 = std::fabs(num1);
    double num2 = stod(argv[2]);
    num2 = std::fabs(num2);

    if (argc > 3) {
        std::cerr << "Introduzca solo 2 lados" << std::endl;
        return 1;
    }

    std::cout << "La hipotenusa de los catetos " << num1 << " y " << num2 << " es " << Hypotenuse(num1, num2) << std::endl;
    return 0;
}