/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file hypotenuse.h
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date	8-11-2025
  * @brief El programa calcula la hipotenusa de dos números dados
  */

#include "hypotenuse.h"

bool IgualSigno(double valor1, double valor2) {
    if (valor1 < 0 && valor2 < 0 || valor1 > 0 && valor2 > 0) {
        return true;
    } else {
        return false;
    }
}

const double epsilon = 1e-4;
double RaizCuadrada(double num) {
    double raiz = sqrt(num);
    double error = 1.0;

    while (fabs((raiz * raiz) - num) > epsilon) {
        while (IgualSigno(error, ((raiz * raiz) - num))) {
            raiz += error;
            eror *= -0.5;
        }
    }
    return raiz;
}

double Hypotenuse(double num1, double num2) {
    num1 *= num1;
    num2 *= num2;
    double hipotenusa;

    hipotenusa = RaizCuadrada(num1) + RaizCuadrada(num2);

    return hipotenusa;
}