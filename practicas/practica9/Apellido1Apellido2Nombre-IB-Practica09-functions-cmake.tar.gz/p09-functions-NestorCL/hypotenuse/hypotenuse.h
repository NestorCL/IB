/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file hypotenuse.h
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date	8-11-2025
  * @brief El programa calcula la hipotenusa de dos números dados
  */

#include <iostream>
#include <cmath>
#include <string>

bool IgualSigno(double valor1, double valor2)

double RaizCuadrada(double num);

double Hypotenuse(double num1, double num2);