/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file polynomial.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date	7-11-2025
  * @brief El programa calcula el valor de una función con los valores dados
  */

#include "polynomial.h"

int Polinomio(std::string coef, int value) {
	int resultado{0}, aux{0}, expo{0};
	expo = coef.size() - 1;
	for (int i = 0; i < coef.size(); i++) {
		aux = std::stoi(std::string(1, coef[i]));
		// double polla = std::pow(value, expo);
		resultado += aux * (std::pow(value, expo));
		// std::cout << aux << " * " << polla << " (" << value << "^" << expo <<") " << " = " << resultado << std::endl;
		expo -= 1;
	}
	return resultado;
}