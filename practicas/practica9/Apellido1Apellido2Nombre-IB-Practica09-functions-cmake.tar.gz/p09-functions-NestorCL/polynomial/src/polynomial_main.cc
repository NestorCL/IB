/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file polynomial.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date	7-11-2025
  * @brief El programa calcula el valor de una función con los valores dados
  */

#include "polynomial.h"

int main(int argc, char* argv[]) {
	std::string coef(argv[1]);
	int value = std::stoi(argv[2]);

	std::cout << Polinomio(coef, value) << std::endl;
	return 0;
}