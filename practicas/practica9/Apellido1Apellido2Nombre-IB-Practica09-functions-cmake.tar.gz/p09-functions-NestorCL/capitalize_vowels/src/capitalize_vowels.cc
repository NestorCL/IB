/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file capitalize_vowels.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 6-11-2025
  * @brief El programa pone en mayúsculas las vocales de uan palabra
  */

#include "capitalize_vowels.h"

std::string CapitalizeVowels(std::string palabra) {
	std::string capitalized;
	for (int i = 0; i < palabra.size(); i++) {
		int letra = int(palabra[i]);
		if (letra == 97 ||  letra == 101 || letra == 105 || letra == 111 || letra == 118) {
			letra -= 32;
			capitalized.push_back(char(letra));
		} else {
			capitalized.push_back(char(letra));
		}
	}
	return capitalized;
}
