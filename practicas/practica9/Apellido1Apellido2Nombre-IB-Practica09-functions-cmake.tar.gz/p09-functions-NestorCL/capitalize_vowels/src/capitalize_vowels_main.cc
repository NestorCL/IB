/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2025-2026
  *
  * @file capitalize_vowels.cc
  * @author Néstor Cozzi Lorenzo alu0101705385@ull.edu.es
  * @date 6-11-2025
  * @brief El programa pone en mayúsculas las vocales de uan palabra
  */

#include "capitalize_vowels.h"

int main(int argc, char* argv[]) {
	std::string palabra(argv[1]);
	
	if (argc > 2) {
		std::cerr << "Has de poner una palabra" << std::endl;
		return 1;
	}

	std::cout << CapitalizeVowels(palabra) << std::endl;
	return 0;
}
